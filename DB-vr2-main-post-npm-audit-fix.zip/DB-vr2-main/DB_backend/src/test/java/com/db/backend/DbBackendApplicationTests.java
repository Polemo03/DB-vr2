package com.db.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
